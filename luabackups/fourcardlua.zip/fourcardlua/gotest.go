package main

import (
	"fmt"
	//"time"
	//"encoding/json"
	//"strings"
	//"math"
	"github.com/yuin/gopher-lua"
)

func main() {

	l := lua.NewState()
	defer l.Close()
	var err error
	if err = l.DoFile("lua/fourcardlua/Logic.lua"); err != nil {
		fmt.Printf("fourcards logic do file %+v", err)
	}

	//ostime := time.Now().UnixNano()
	//if err = l.DoString(fmt.Sprintf("return G_Init(%d)", ostime)); err != nil {
	//	fmt.Printf("doudizhu G_Init error %+v", err)
	//	return
	//}
	//
	//if err := l.DoString("return G_Reset()"); err != nil {
	//	fmt.Printf("doudizhu G_Reset %+v", err)
	//	return
	//}

	gameStr :="{'UserDice':{'UserID':104041,'DiceAPoints':2,'DiceBPoints':2},'List':[{'UserID':100002,'Status':130,'Bet':1,'Role':1,'CardList':['1_5','2_10','1_11','3_8'],'HeadCards':{'Win':22,'Score':5,'CardType':4,'CardList':['1_5','2_10']},'TailCards':{'Win':25,'Score':9,'CardType':6,'CardList':['1_11','3_8']},'TotalScore':47},{'UserID':104053,'Status':130,'Bet':1,'Role':2,'CardList':['4_4','1_9','3_7','1_6'],'HeadCards':{'Win':0,'Score':0,'CardType':4,'CardList':['1_6','4_4']},'TailCards':{'Win':-6,'Score':6,'CardType':3,'CardList':['1_9','3_7']},'TotalScore':-6},{'UserID':104054,'Status':130,'Bet':1,'Role':2,'CardList':['3_9','1_4','3_3','2_8'],'HeadCards':{'Win':-7,'Score':7,'CardType':2,'CardList':['2_8','3_9']},'TailCards':{'Win':-7,'Score':7,'CardType':5,'CardList':['1_4','3_3']},'TotalScore':-14},{'UserID':104055,'Status':130,'Bet':1,'Role':2,'CardList':['1_12','3_12','4_6','5_21'],'HeadCards':{'Win':-7,'Score':7,'CardType':4,'CardList':['4_6','5_21']},'TailCards':{'Win':12,'Score':12,'CardType':100,'CardList':['1_12','3_12']},'TotalScore':5},{'UserID':104041,'Status':130,'Bet':1,'Role':2,'CardList':['3_2','3_5','4_8','2_6'],'HeadCards':{'Win':-4,'Score':4,'CardType':4,'CardList':['2_6','4_8']},'TailCards':{'Win':-7,'Score':7,'CardType':7,'CardList':['3_2','3_5']},'TotalScore':-11},{'UserID':100019,'Status':130,'Bet':1,'Role':2,'CardList':['4_7','3_6','1_2','3_4'],'HeadCards':{'Win':0,'Score':0,'CardType':5,'CardList':['3_4','3_6']},'TailCards':{'Win':-9,'Score':9,'CardType':7,'CardList':['1_2','4_7']},'TotalScore':-9},{'UserID':100012,'Status':130,'Bet':1,'Role':2,'CardList':['4_10','1_7','1_8','2_7'],'HeadCards':{'Win':-4,'Score':4,'CardType':3,'CardList':['1_7','2_7']},'TailCards':{'Win':-8,'Score':8,'CardType':6,'CardList':['1_8','4_10']},'TotalScore':-12}]}"
	roomStr := "{\"ScoreType\":2,\"BetType\":2}'"
	if err := l.DoString(fmt.
	Sprintf("return G_CalculateRes('%s','%s')",
		gameStr, roomStr)); err != nil {
		fmt.Printf("four card G_CalculateRes err %v", err)
		return
	}

	getCards := l.Get(-1)
	l.Pop(1)
	fmt.Printf("TEST:%v\n", getCards.String())
	//if err := json.Unmarshal([]byte(getCards.String()), &gameInit); err != nil {
	//	print(err)
	//}

	//test := []string{"131","阿斯达","qweq"}
	////var args [len(test)]interface{}
	//args := make([]interface{}, len(test))
	//for i,v := range test{
	//	args[i] = v
	//}
	//f := fmt.Sprintf("%s|%s|%s", args...)
	//fmt.Printf(f)

}
