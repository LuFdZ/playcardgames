--表示牌的KEY
CardName = { "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "JB" }

CardWay = {
    --  分值
    _score,
    --  牌型
    _type,
    --  索引
    _index,
    --  可组成的头尾道的另一道的索引
    _group,
    -- 总分值
    _value,
    --  牌组
    _cardlist
}

function CardWay:new(s, t, i, v, l)
    self = {}
    setmetatable(self, Card)
    self._score = s
    self._type = t
    self._index = i
    self._value = v
    self._cardlist = l
    return self
end

--
--牌型大小
--至尊 > 天牌对 > 地牌对 > 人牌对 > 和牌对 > 长牌对 > 短牌对 > 杂牌对 > 天王 > 天杠 > 地杠 > 点数
local CardGroupKV = {
    ["3_3-5_21"] = 110, --至尊：大王+红桃3
    ["1_12-3_12"] = 100, --天牌对：2张红Q

    ["1_2-3_2"] = 90, --地牌对：2张红2

    ["1_8-3_8"] = 80, --人牌对：2张红8

    ["1_4-3_4"] = 70, --和牌对：2张红4

    ["2_10-4_10"] = 60, --长牌对：2张黑10、黑6、黑4
    ["2_6-4_6"] = 60,
    ["2_4-4_4"] = 60,
    ["1_11-3_11"] = 50, --短牌对：2张红J、红10、红7、红6
    ["1_10-3_10"] = 50,
    ["1_7-3_7"] = 50,
    ["1_6-3_6"] = 50,
    ["1_9-3_9"] = 40, --杂牌对：2张红9、黑8、黑7、红5
    ["1_5-3_5"] = 40,
    ["2_7-4_7"] = 40,
    ["2_8-4_8"] = 40,
    ["1_12-1_9"] = 30, --天王：红Q+红9
    ["3_12-3_9"] = 30,
    ["1_9-3_12"] = 30,
    ["1_12-3_9"] = 30,
    ["1_12-1_8"] = 20, --天杠：红Q+任意8
    ["1_12-2_8"] = 20,
    ["1_12-3_8"] = 20,
    ["1_12-4_8"] = 20,
    ["1_8-3_12"] = 20,
    ["2_8-3_12"] = 20,
    ["3_12-3_8"] = 20,
    ["3_12-4_8"] = 20,
    ["1_2-1_8"] = 10, --地杠：红2+任意8
    ["1_2-2_8"] = 10,
    ["1_2-3_8"] = 10,
    ["1_2-4_8"] = 10,
    ["1_8-3_2"] = 10,
    ["2_8-3_2"] = 10,
    ["3_2-3_8"] = 10,
    ["3_2-4_8"] = 10,
}
--同样点数，根据2张中较大的一张牌的牌型比大小
--天牌>地牌>人牌>和牌>长牌>短牌>杂牌>大王/红桃3
local CardKV = {
    ["1_12"] = 8; --天牌 红Q
    ["3_12"] = 8;

    ["1_2"] = 7; --地牌 红2
    ["3_2"] = 7;

    ["1_8"] = 6; --人牌 红8
    ["3_8"] = 6;

    ["1_4"] = 5; --和牌 红4
    ["3_4"] = 5;

    ["2_10"] = 4; --长牌 黑10、黑6、黑4
    ["2_6"] = 4;
    ["2_4"] = 4;
    ["4_10"] = 4;
    ["4_6"] = 4;
    ["4_4"] = 4;

    ["1_11"] = 3; --短牌 红J、红10、红7、红6
    ["1_10"] = 3;
    ["1_7"] = 3;
    ["1_6"] = 3;
    ["3_11"] = 3;
    ["3_10"] = 3;
    ["3_7"] = 3;
    ["3_6"] = 3;

    ["1_9"] = 2; --杂牌 红9、黑8、黑7、红5
    ["1_5"] = 2;
    ["2_8"] = 2;
    ["2_7"] = 2;
    ["3_9"] = 2;
    ["3_5"] = 2;
    ["4_8"] = 2;
    ["4_7"] = 2;

    ["3_3"] = 1; --红桃3

    ["5_21"] = 1; --大王
}
ScoreKV = {
    [110] = 13, --至尊13分
    [100] = 12, --对子12分
    [90] = 12,
    [80] = 12,
    [70] = 12,
    [60] = 12,
    [50] = 12,
    [40] = 12,
    [30] = 11, --天王11分
    [20] = 10, --天杠10分
    [10] = 10, --地杠10分
}

local CardPoint = {
    ["1_12"] = 12; --天牌 红Q
    ["3_12"] = 12;

    ["1_2"] = 2; --地牌 红2
    ["3_2"] = 2;

    ["1_8"] = 8; --人牌 红8
    ["3_8"] = 8;

    ["1_4"] = 4; --和牌 红4
    ["3_4"] = 4;

    ["2_10"] = 10; --长牌 黑10、黑6、黑4
    ["2_6"] = 6;
    ["2_4"] = 4;
    ["4_10"] = 10;
    ["4_6"] = 6;
    ["4_4"] = 4;

    ["1_11"] = 11; --短牌 红J、红10、红7、红6
    ["1_10"] = 10;
    ["1_7"] = 7;
    ["1_6"] = 6;
    ["3_11"] = 11;
    ["3_10"] = 10;
    ["3_7"] = 7;
    ["3_6"] = 6;

    ["1_9"] = 9; --杂牌 红9、黑8、黑7、红5
    ["1_5"] = 5;
    ["2_8"] = 8;
    ["2_7"] = 7;
    ["3_9"] = 9;
    ["3_5"] = 5;
    ["4_8"] = 8;
    ["4_7"] = 7;

    ["3_3"] = 3; --红桃3

    ["5_21"] = 6; --大王
}
--}
Card = {
    --  1,2,3,4,5 对应：方块，梅花，红心，黑桃，大王
    _type,
    --【牌型规则】
    --牌型(共32张)
    --1、天牌对：2张红Q
    --2、地牌对：2张红2
    --3、人牌对：2张红8
    --4、和牌对：2张红4
    --5、长牌对：2张黑10、黑6、黑4
    --6、短牌对：2张红J、红10、红7、红6
    --7、杂牌对：2张红9、黑8、黑7、红5
    --8、至尊：大王+红桃3
    --9、天王：红Q+红9
    --10、天杠：红Q+任意8
    --11、地杠：红2+任意8
    _value
}
Card.__index = Card

function Card:new(t, v)
    self = {}
    setmetatable(self, Card)
    self._type = t
    self._value = v
    return self
end

function UserCardCount(user)
    --    if user.Type == 2 then
    --        AutoUserResult(user)
    --    else
    --        user.HeadCards.Score, user.HeadCards.CardType, user.HeadCards.Value = GetUserResult(user.HeadCards.CardList)
    --        user.TailCards.Score, user.TailCards.CardType, user.HeadCards.Value = GetUserResult(user.TailCards.CardList)
    --    end
    GetUserResult(user.HeadCards)
    GetUserResult(user.TailCards)
end

function GetUserResult(userCard)
    table.sort(userCard.CardList, function(c1, c2)
        -- body
        return c1 < c2
    end)
    local cardA = userCard.CardList[1]
    local cardB = userCard.CardList[2]
    local typeKey = cardA .. "-" .. cardB
    local cardType = CardGroupKV[typeKey]
    local score = 0
    local value = 0
    if cardType == nil then
        local cardAValue = CardKV[cardA]
        local cardBValue = CardKV[cardB]
        if cardAValue > cardBValue then
            cardType = cardAValue
        else
            cardType = cardBValue
        end

        local cardAScore = CardPoint[cardA] --tonumber(arrA[2])
        local cardBScore = CardPoint[cardB] --tonumber(arrB[2])
        score = (cardAScore + cardBScore) % 10
        if score > 0 then
            value = score * 10 + cardType
        else
            value = 0
            cardType = 0
        end

    else
        score = ScoreKV[cardType]
        value = cardType * 100
    end
    userCard.Score = score
    userCard.CardType = cardType
    userCard.Value = value
    return score, cardType, value
end

function ChekcUserCardList(head, tail)
    local headScore, headType, headValue = GetUserResult(head)
    local tailScore, tailType, tailValue = GetUserResult(tail)
    if headValue > tailValue then
        return false
    else return true
    end

    --    if headType >= 10 and tailType < 10 then --头道大于尾道
    --        return false
    --    elseif headType >= 10 and tailType >= 10 then --头道是牌组 尾道也是牌组
    --        if headType > tailType then --头道大于尾道
    --            return false
    --        end
    --    elseif headType < 10 and tailType < 10 then --头道不是牌组 尾道也不是牌组
    --        if headScore > tailScore then --头道分值大于尾道分值
    --            return false
    --        elseif headScore == tailScore and headScore ~= 0 and headType > tailType then --头道分值小于尾道分值 头道单牌类型小于尾道单牌类型
    --            return false
    --        end
    --    end
    --    return true
end


function AutoUserResult(user)
    local head, tail = AutoGetCards(user.CardList)
    user.HeadCards.CardList = head._cardlist
    user.TailCards.CardList = tail._cardlist
end

function AutoGetCards(cardList)
    --    local cardList = { "1_10", "2_10", "4_4", "3_2" }
    --    --local cardlist = { "1_7", "2_7", "4_6", "3_4" }
    --    local tmp = { "3_3", "5_21", "1_2", "3_2" }
    local combs = {} -- 牌组组合容器
    local result = {} -- 牌组结果所以分组容器（不用）
    local tmpCardWays = {} -- 尾道备选牌组容器

    local MaxValue = 0 -- 最大牌组比较分
    local MaxValueNumber = 0 -- 同为最大比较分的牌组数量
    Combine_increase(combs, cardList, result, 1, 2, 2)
    local len = #combs
    for t = 1, #combs do
        local cardA = combs[t][1]
        local cardB = combs[t][2]
        wayCardList = { cardA, cardB }

        local score, type, value = GetUserResult(wayCardList)
        local CardWay = CardWay:new(score, type, t, value, wayCardList)
        CardWay._group = len - (t - 1)
        table.insert(tmpCardWays, CardWay)
        if MaxValue < value then
            MaxValue = value
            MaxValueNumber = 0
        elseif MaxValue == value then
            MaxValueNumber = MaxValueNumber + 1
        end
    end

    local maxCardWays = tmpCardWays[1]
    for t = 2, #tmpCardWays do
        if tmpCardWays[t]._value > maxCardWays._value then
            maxCardWays = tmpCardWays[t]
        elseif tmpCardWays[t]._value == maxCardWays._value and
                tmpCardWays[tmpCardWays[t]._group]._value > tmpCardWays[maxCardWays._group]._value then
            --            print(maxCardWays._group .. "|" .. tmpCardWays[t]._group)
            maxCardWays = tmpCardWays[t]
        end
    end

    --    print(maxCardWays._index .. ":" .. maxCardWays._cardlist[1] .. "-" .. maxCardWays._cardlist[2] .. "|" .. tmpCardWays[maxCardWays._group]._index .. ":" .. tmpCardWays[maxCardWays._group]._cardlist[1] .. "-" .. tmpCardWays[maxCardWays._group]._cardlist[2])
    --
    --    table.sort(tmpCardWays, function(cardway1, cardway2)
    --        if cardway1._value > cardway2._value then
    --            return true
    --        else return false
    --        end
    --    end)
    --    for t = 1, #tmpCardWays do
    --        print(tmpCardWays[t]._index .. "|" .. tmpCardWays[t]._group .. "|" .. tmpCardWays[t]._score .. "|" .. tmpCardWays[t]._type .. "|" .. tmpCardWays[t]._value .. "|" .. tmpCardWays[t]._cardlist[1] .. "-" .. tmpCardWays[t]._cardlist[2])
    --    end
    local head = {}
    local tail = {}
    if tmpCardWays[maxCardWays._group]._value > maxCardWays._value then
        head = maxCardWays
        tail = tmpCardWays[maxCardWays._group]
    else
        head = tmpCardWays[maxCardWays._group]
        tail = maxCardWays
    end
    --print(head._index .. ":" .. head._cardlist[1] .. "-" .. head._cardlist[2] .. "|" .. tail._index .. ":" .. tail._cardlist[1] .. "-" .. tail._cardlist[2])

    return head, tail
end


--查找所有组合,combs:结果， cards:所有的牌， res：一组结果的索引, start:开始的索引, count:查找到第几个, num：组合中元素个数
function Combine_increase(combs, cards, res, start, count, num)

    if cards == nil then
        return
    end

    for i = start, #cards + 1 - count do
        res[count] = i
        if count == 1 then
            card = {}
            for j = num, 1, -1 do
                card[j] = cards[res[j]]
            end
            table.insert(combs, card)
        else
            Combine_increase(combs, cards, res, i + 1, count - 1, num)
        end
    end
end
