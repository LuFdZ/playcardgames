--
-- Created by IntelliJ IDEA.
-- User: lufdz
-- Date: 2018/2/3
-- Time: 03:39
-- To change this template use File | Settings | File Templates.
--
--require "/Users/lufdz/GoPro/src/playcards/bin/lua/fourcardlua/Tools.lua"


function AutoGetCards()
    local cardlist = {"3_3","5_21","1_2","3_2"}
    local combs = {}
    local result = {}
    Combine_increase(combs, cardlist, result, 1, 2, 2)
    for t = 1, 6 do
    local a = combs[t][1]
    local b = combs[t][2]
    print(a .."|".. b)
    end
end

--查找所有组合,combs:结果， cards:所有的牌， res：一组结果的索引, start:开始的索引, count:查找到第几个, num：组合中元素个数
function Combine_increase(combs, cards, res, start, count, num)

    if cards == nil then
        return
    end

    for i = start, #cards + 1 - count do
        res[count] = i
        if count == 1 then
            card = {}
            for j = num, 1, -1 do
                card[j] = cards[res[j]]
            end
            table.insert(combs, card)
        else
            Combine_increase(combs, cards, res, i + 1, count - 1, num)
        end
    end
end

AutoGetCards()

