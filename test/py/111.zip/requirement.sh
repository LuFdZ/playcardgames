#!/usr/bin/env bash

sudo pip install websocket-client
sudo pip install httplib2
